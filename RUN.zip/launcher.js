const { fork } = require('child_process');
const path = require('path');

// Número de instancias paralelas
const instances = 35;

// Ruta del script a ejecutar
const scriptPath = path.resolve(__dirname, 'worker.js');

// Ejecutar múltiples instancias del script
for (let i = 0; i < instances; i++) {
    const worker = fork(scriptPath);

    worker.on('message', (msg) => {
        console.log(`[Worker ${i}] ${msg}`);
    });

    worker.on('exit', (code) => {
        console.log(`[Worker ${i}] terminated with code: ${code}`);
    });
}
